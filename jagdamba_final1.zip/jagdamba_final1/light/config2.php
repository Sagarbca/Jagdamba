<?php
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'succeky5_succexa');
   define('DB_PASSWORD', '~f_uR)+v,*bS');
   define('DB_DATABASE', 'succeky5_jgdmba');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>