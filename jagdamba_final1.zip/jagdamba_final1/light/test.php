<!DOCTYPE html>
<html>
<body>

<?php
echo substr("28.666666666666",0,5);
?>

</body>
</html>