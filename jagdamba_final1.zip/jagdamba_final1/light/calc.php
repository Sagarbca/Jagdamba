<?php 


 $total_due = 1000 - (-33);
      echo $total_due;



?>